<?php

/*
 * xevents REGISTER WIDGETS FILES.
 * xevents WordPress Theme 
 * Theme URI: http:/www.wpmeal.com/xevents
 */
/*
function xevents_inc_widgets_files() {
    wp_register_style('gplus-light-allday', get_template_directory_uri() . '/biz/assets/gplus_activity_widget/light.css');
    wp_register_style('tweets_allday', get_template_directory_uri() . '/biz/css/widgets/tweets_style.css');

    if (is_active_widget(false, false, 'xevents_gplus_widget', true)) {
        wp_enqueue_style('gplus-light-allday');
    }
    if (is_active_widget(false, false, 'xevents_tweets_widget', true)) {
        wp_enqueue_style('tweets_allday');
    }
}

add_action('init', 'xevents_inc_widgets_files');*/
?>