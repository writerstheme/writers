 jQuery(document).ready(function($) {
 

// style Select, Radio, Checkbox
  
    if ($("div,p").hasClass("input_styled")) {
       
        $(".input_styled input").customInput();
    }



});