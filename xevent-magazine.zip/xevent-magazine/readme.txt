Theme Name: Xevent Magazine.
Theme URI: http://wpmeal.com/xevent_theme/ .
Author: WPMEAL .
Author URI: http://wpmeal.com .
License: GPL .
License URI: http://www.gnu.org/licenses/gpl-3.0.en.html .
About Author - Contact Details .
email: http://wpmeal.com/contact.php .
Theme Resources:
Theme is Built using the following resources:
- classie MIT license.
- fotorama MIT license . 
- iview license: https://github.com/iprodev/iView/blob/master/LICENSE.
- jQuery Cycle Plugin  Dual licensed under the MIT and GPL licenses.
- jQuery Easing Open source under the BSD License.
- flexslider MIT licens.
- imagesLoaded MIT license.
- Marquee jQuery Plug-in Apache License.
- prettyPhoto gpl license.
- SlickNav MIT license.
- SliderTabs MIT license.
- Smallipop MIT license.
- jquery sticky license: https://github.com/garand/sticky/blob/master/LICENSE.md .
- wookmark MIT license.
- jquery ui MIT license. 
- Owl carousel MIT license. 
- Raphael MIT license.
- Respond.js MIT license.
- response.js MIT license.
- tabs.js NO COPYRIGHTS OR LICENSES. DO WHAT YOU LIKE. 
- video.js Apache License.
- WOW MIT License.
- Bootstrap Licensed under MIT.
- gplus activity widget Licensed under the Apache License.
- Spectrum Colorpicker License MIT.
- totem MIT License.
- wp-bootstrap-navwalker-master gpl license.
- font awesome License MIT.
- all images and icons Licensed under gpl.